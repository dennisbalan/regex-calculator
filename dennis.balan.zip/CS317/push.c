#include "header.h"
//adds a new node *input to the top of stack* list
void push(stack *list,node *input){
	//increment list->count
	list->count++;
	//create a new stack* element new
	stack *new = malloc(sizeof(stack));
	//set new->nfa to input
	new->nfa = input;
	//set the new up so that the sentinel points to new, and new points to the previous top element old
	stack *old = list->next;
	list->next = new;
	new->next = old;
}
