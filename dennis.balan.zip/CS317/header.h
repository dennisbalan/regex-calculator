#include <stdio.h>
#include <stdlib.h>
//struct node is the nfa struture implement as a linked list
//its main features are name(start state), transition (symbol) and next_state(final state)
//next is the next node in the nfa structure
typedef struct node{
        int name;
        char transition;
        int next_state;
        struct node* next;
}node;
//stack is the stack used to control nfas which includes a pointer to the nfa (node *nfa), next ptr that is used in linked listing and count, the number of elements in the stack
typedef struct stack{
        node *nfa;
        struct stack *next;
	int count;
}stack;
//array is node in array form, used for qsort
typedef struct array{
	int name;
	char transition;
	int next_state;
}array;

