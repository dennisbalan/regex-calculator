#include "header.h"
//take an input of node *nfa, and perform a star operation on it. return the new node *new with new state i
node *star(node *nfa, int i){
	//initialze node *new
	node *new = malloc(sizeof(node));
	//create an e-transition with transition set to 'E'
	new->transition = 'E';
	//set the new state's name to i
	new->name = i;
	//new->next_state is nfa->name, or the initial start state
	new->next_state = nfa->name;
	//new is set to point to nfa
	new->next = nfa;
	//interate through nfa unti nfa is NULL
	while(nfa->next != NULL){
		nfa = nfa->next;
	}
	//initialzie node *other
	node *other = malloc(sizeof(node));
	//transition is an e-transiton
	other->transition = 'E';
	//other's start state is nfa's accept state
	other->name = nfa->next_state;
	//other's final state is i
	other->next_state = i;
	//set other->next to NULL
	other->next = NULL;
	//set nfa->next to other
	nfa->next = other;
	//return new
	return new;
}
