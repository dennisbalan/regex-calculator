#include "header.h"
/*takes an input of 2 struct node ptrs, input1 and input2 (the nfas) and performs a concatenation operation on both. A new nfa is returned*/
node *concat(node *input1, node *input2){
	//curr, the return value is initially set to input1
	struct node *curr = input1;
	struct node *return_value = curr;
	//iterate through all of curr to get to the end_state of input1
	while(curr->next != NULL){
		curr= curr->next;
	}
	//create a new element node (nfa)
	node *new = malloc(sizeof(node));
	//curr->next points to the new element, and a new transition is created. new->name is set to curr's next_state, the transition is Episolon, and the next_state is the name of input2's start state
	curr->next = new;
	new->name = curr->next_state;
	new->transition = 'E';
	new->next_state = input2->name;
	//set new's next value to input2
	new->next=input2;
	//return the nfa
	return return_value;
}
