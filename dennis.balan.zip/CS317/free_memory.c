#include "header.h"
extern void free_nfa(node *);
//iterate throught the stack linked list until stack *list is NULLand free everything inside
void free_memory(stack *list){
	while(list != NULL){
		stack *a = list;
		list = list->next;
		//free the node *nfa inside a
		free_nfa(a->nfa);
		free(a);
	}
}
