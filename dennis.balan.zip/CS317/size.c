#include "header.h"
//return the size of node* nfa. Iterate through the linked list and count the number of elements in it
int size(node *nfa){
	int i = 1;
	struct node *current = nfa;
	while(current != NULL){
		if(current=current->next){
			i++;
		}
	}
	return i;
}
