Personal

Dennis Balan
dennis.balan@wsu.edu

List of files

main.c:Main function where most of the work is done
init\_stack.c:initializes the stack as a linked list
push.c:push an element into the stack by adding it to the linked list. 
pop.c:pop an element from the stack by removing the top element and returning it as an nfa
single.c: creates an nfa from a single operator(a,b,c,d,e,E) being inputted
star.c: performs a star operation on the nfa
intersect.c: performs a union on two nfas. made a mental error and mislabed the file and function as intersection
concat.c:performs a union operation on two nfas
size.c:finds the size of the nfa linked list
print.c:prints the start and accept states of an nfa, fixes any uninitialized value mistakes
sort.c:takes an nfa linked list, place its element into an array,sort it with qsort and print the content of the array
size\_compare.c:size compare function for qsort
free\_memory.c: frees the stack structure
free\_nfa.c:frees the nfa(node) structure
header.h:universal header file that contains the code for the stack, nfa and array structures

Compile instructions:
	Run make. The makefile will compile the target program engine

Run instructions:
	Program requires the file to be a command line input(aka argv) to properly run.
	Example: 
		./engine file_input
Overview:
	engine takes an input text file of regular expressions and processes each line to create an NFA. After its creation, the start and accept states of the NFA, along with the contents of the NFA are printed in a sorted list. 3 data structures are primarily used - stack, which is used to create the stack that stores each nfa, node, which is the nfa structure, and array, which is a struct array used for sorting. engine can do 3 operations on the regex input = union, concatenation and Kleene star. After a line of text has been processed, the start and accept states are printed, the nfa (node) structure is put into an array structure. The array structure is sorted in qsort, and the array elements are printed in sorted order
