#include "header.h"
//intersect is the function used to create a union of two node ptrs (nfa1 and nfa2). it takes an input of two node * ptrs (the nfa) and int i, which is used to label the new states
// two node ptr element pointers are created to simulate a new state with two transitions.its two next states are the first element in nfa1 and the first element in nfa2
//  those ptrs are linked to each other, and the 2nd pointer is linked to the first nfa, and the first nfa is linked to the second nfa.
//  Two more node * elements are created that contain the final state in the new nfa. it sets the accept state to i+1 by setting the next_state field of each i+1, with nfa1's accept state amd nfa2's accept state servings as E-transitions to i+1. After those two states are linked to the final node *, it is returned
node *intersect(node *nfa1, node *nfa2, int i){
	//create 2 new states new1 and new2.
	int s = i+1;
	node *new1 = malloc(sizeof(node));
	//Create a state i by setting new1 and new2 name to i, transition to E. new1 and new2 next_state are the start states in nfa1 and nfa2(nfa1->name, nfa2->name) respectively
	new1->name = i;
	new1->transition = 'E';
	new1->next_state = nfa1->name;
	node *new2 = malloc(sizeof(node));
	//new1 points to new2
	new1->next = new2;
	new2->name = i;
	new2->transition = 'E';
	new2->next_state = nfa2->name;
	//set node ptr iterator to new2 so that nfa1 can be traversed
	node *iterator = new2;
	//end_state1 is going to be the accept_state of nfa1. initialzed to 0 for now 
	int end_state1 = 0;
	//Copy the elements of nfa1 into the new node*. while nfa1 is not NULL, create a new node ptr new, whose fields are set to those nfa1. nfa1 will keep getting set to nfa->next,while iterator->next is constantly set to new
	while(nfa1 != NULL){
		node *new = malloc(sizeof(node));
		new->name = nfa1->name;
		new->next_state = nfa1->next_state;
		new->transition = nfa1->transition;
		//end_state1 is continuously set to the next state to get the accep state
		end_state1 = new->next_state;
		iterator->next = new;
		iterator = iterator->next;
		nfa1 = nfa1->next;
	}
	//end_state2 is going to be the accept state of nfa2. Initialized to 0 for now
	int end_state2 = 0;
	//copy the elements of nfa2 into the new node*.Content of the loop is similar to the nfa1 iteration, refer to it for comments 
	//nfa1's next ptr is set to nfa2 here
	while(nfa2 != NULL){
		node *new = malloc(sizeof(node));
		new->name = nfa2->name;
		new->next_state = nfa2->next_state;
		new->transition = nfa2->transition;
		//end_state2 is consistently to the next state to get the accept state
		end_state2 = new->next_state;
		iterator->next = new;
		iterator = iterator->next;
		nfa2 = nfa2->next;
	}
	//create 2 new node* ptrs new3 and new4. They are the e-transitions to the final state i+1. name of each element is end_state1 and end_state2 for new3 and new4 respectively. transition is 'E', next_state is s, or i+1, 
	node *new3 = malloc(sizeof(node));
	node *new4 = malloc(sizeof(node));
	new3->name = end_state1;
	new3->transition = 'E';
	new3->next_state = s;
	//the iterator's next is set to new3
	iterator->next = new3;
	//new3 next is new4
	new3->next = new4;
	new4->name = end_state2;
	new4->transition = 'E';
	new4->next_state = s;
	//new4 next is NULL
	new4->next = NULL;
	//return the final nfa in new1
	return new1;
}
