#include "header.h"
//size_compare function for qsort. compares the array elements name of i and j to sort smallest to largest
int size_compare(const void *a, const void *b){
	array *i = (array*)a;
	array *j = (array*)b;
	return(i->name-j->name);
}
