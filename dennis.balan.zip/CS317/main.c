/*
 *
 *engine takes a command line argumenent as an input. The arguemnt must be a file with one regular expression per line. It reads the file line by line, converting each regular expression into an nfa, which is then printed
 *
 * */
#include "header.h"
stack *init_stack();
node *pop(stack*);
void push(stack*, node*);
node *single(char,int);
node *star(node *, int);
node *concat(node *, node *);
node *intersect(node *, node *, int);
void sort(node *);
void print(node *);
int size(node *);
void free_memory(stack*);
void free_nfa(node *);
int main(int argc, char **argv){
	//create file pointer fp and if there is one command line argument in argv, open argv[1] as a file
	FILE *fp;
	if(argc == 2){
		fp = fopen(argv[1],"r");
	}
	//error check for no command line arguement. print error and exit
	else{
		printf("You need one command line argument as the input file to run\n");
		exit(0);
	}
	//set string buffer to read each line
	char buffer[256];
	//initialize stack *stack
	stack *list = init_stack();
	//j is the running state count
	int j = 1;
	//set error to 0 to indicate no error, error is set 1 if error exists
	int error = 0;
	//read each line by line in argv[1]
	while(fgets(buffer,256,fp)){
		//set i string iterator to 0
		int i = 0;
		//print the regular expression
		printf("RE: %s",buffer);
		//iterate through entire string until you get to new line
		while(buffer[i] != '\n'){
			//check to see if buffer[i] is a valid letter symbol or e-epsilon ('E')
			//if so, create a single nfa that contains a basic nfa - a start state with a buffer[i] transition to an accept state
			if((buffer[i] == 'a') || (buffer[i] == 'b') || (buffer[i] == 'c') || (buffer[i] == 'd') || (buffer[i] == 'e') || (buffer[i] == 'E')){
				node *nfa1 = single(buffer[i],j);
				//single requires 2 new states, as such j is added a 2
				j=j+2;
				//push nfa1 to list
				push(list,nfa1);
				//increment i after reading buffer[i]
				i++;
			}
			//check to see if buffer[i] is *. if so, perform a clean star operation
			else if(buffer[i] == '*'){
				//if not enough elements in stack, print error message, set error to 1 and break the loop
				if(list->count < 0){
					printf("Error. Invalid * input\n");
					error = 1;
					break;
				}
				//nfa1 is the nfa popped from the stack
				node *nfa1 = pop(list);
				//star operation is performed on nfa1
				nfa1 = star(nfa1,j);
				//one new state was created, increment j by 1
				j++;
				//push nfa1 to list
				push(list,nfa1);
				//iterate i after reading bugger[i]
				i++;
			}
			//if buffer[i] is '&', perform union operation
			else if(buffer[i] == '&'){
				if(list->count < 2){
					printf("Error. Invalid & input\n");
					error = 1;
					break;
				}
				//pop the top two elements from list and perform a concat operation of those 2 elements,setting node *nfa3 to the result of concat, push nfa3 to list
				node *nfa1 = pop(list);
				node *nfa2 = pop(list);
				node *nfa3 = concat(nfa2,nfa1);
				push(list,nfa3);
				//increment i
				i++;
			}
			//if buffer[i] is '|', perform a union operation
			else if(buffer[i] == '|'){
				//error check if there are not enough elements in stack. if so print error message, set error to 1 and break the loop
				if(list->count < 2){
					printf("Error. Invalid | input\n");
					error = 1;
					break;
				}
				//pop the two top elements in list, node *nfa1 and *nfa2 and perform a union operation in intersect, saving the nfa in node *nfa3. the new nfa3 is pushed to list
				node *nfa1 = pop(list);
				node *nfa2 = pop(list);
				node *nfa3 = intersect(nfa2,nfa1,j);
				//push nfa3 to list
				push(list,nfa3);
				//2 new states needed for intersect, set j to 2
				j = j+2;
				//increment string counter i
				i++;
			}
			//if there was a non-acceptable symbol
			else{
				printf("Prohibitted symbol. Must be a,b,c,d,e,E,*,& or |.\n");
				error = 1;
				break;
			}
		}
		//if no error, pop the top element of list and save it in node *nfa. print prints the the start and accept states of nfa, while sort sorts nfa and prints a sorted version of it
		if(error == 0){
			node *nfa = pop(list);
			print(nfa);
			sort(nfa);
		}
		//to read a new line, reset error to 0 and j to 1 to get correct output
		error = 0;
		j = 1;
	}
	//close the file pointer fp
	fclose(fp);
}

