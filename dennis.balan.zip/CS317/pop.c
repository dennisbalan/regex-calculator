#include "header.h"
//remove the top element from stack *list and return it as a node* value;
node *pop(stack *list){
	//decerement the count of list
	list->count = list->count-1;
	//set temp variable list and iterate to the top element of the stack that is not the sentinel 
	stack *temp = list->next;
	//set the sentinel's next to temp->next
	list->next = temp->next;
	//set the return_value to temp->nfa, the node*of the nfa
	node *return_value = temp->nfa;
	//free the garabge in temp
	free(temp);
	//return the node *
	return return_value;
}
