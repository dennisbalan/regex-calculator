#include "header.h"
//stack initializes the stack linked linked list and returns a stack*;
stack *init_stack(){
	//list is the sentinel
	stack *list = malloc(sizeof(stack));
	//set next to 0
	list->next = NULL;
	//set inital count to 0
	list->count = 0;
	return list;
}
