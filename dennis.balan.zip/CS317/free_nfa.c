#include "header.h"
//free the nfa linked list until node *nfa is NULL
void free_nfa(node *nfa){
	while(nfa != NULL){
		node *a = nfa;
		nfa = nfa->next;
		free(a);
	}
}
