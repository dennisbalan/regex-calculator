#include "header.h"
extern int size(node *nfa);
extern int size_compare(const void *,const void *);
extern void free_nfa(node *);
//copy the node *nfa into new array element item and qsort it. print the qsorted result;
void sort(node *nfa){
	//get the size of nfa in size() and save it in a
	int a = size(nfa);
	//create iterator i
	int i = 0;
	//create array of array elements item
	array *item = (array*)calloc(a,sizeof(item));
	//copy the elements of nfa into item
       	while(nfa != NULL){	
		item[i].name = nfa->name;
		item[i].transition = nfa->transition;
		item[i].next_state = nfa->next_state;
		i++;
		nfa = nfa->next;
	}
	//sort item in qsort smallest to largest, specifically the start states name
	qsort(item,a,sizeof(array),size_compare);
	int j = 0;
	//print the final version of the nfa in the form - start,transition -> final, one per line
	while(j < a){
		printf("(q%d,%c) -> q%d\n",item[j].name,item[j].transition,item[j].next_state);
		j++;
	}
	//free the garbage
	free(item);
	//free the nfa in free_nfa()
	free_nfa(nfa);
}

