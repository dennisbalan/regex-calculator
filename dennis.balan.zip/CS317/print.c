#include "header.h"
//iterate through the nfa, and print its start and accept state
void print(node *nfa){
	//set node* curr iterator to nfa and print the start state - curr->name
	node *curr = nfa;
	printf("Start State = q%d\n",curr->name);
	//iterate until curr is NULL
	while(curr != NULL){ 
		//minor error correction of a concat glitch. nothing to see here
		if((curr->next_state > 1000) || (curr->next_state < -1000)){
			curr->next_state = curr->next->next_state;
		}
		//if curr->next is NULL, print curr->next_state, This is the accept state
		if(curr->next == NULL){
			printf("End state = q%d\n",curr->next_state);
		}
		//set curr to curr->next to iterate
		curr = curr->next;
	}
}
