#include "header.h"
//create a new nfa with a single transition with inputs char a the transition and int i the state counter. return node *nfa after all the elements are set
node *single(char a,int i){
	//initialze node *nfa 
	node *nfa = malloc(sizeof(node));
	//name or start state is i 
	nfa->name = i;
	//transition is a
	nfa->transition = a;
	//accept state is i+1
	nfa->next_state = i+1;
	//next is set to NULL, the nfa is implement as a linked list
	nfa->next = NULL;
	//return the nfa
	return nfa;
}
